
<?php $__env->startSection('title'); ?>
<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('frontent.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 107px;">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-6">
					<div class="map-holder pt160 pb160">
			          <iframe src="http://maps.google.com/maps?q=<?php echo e($WeBeliveIn->lng); ?>,<?php echo e($WeBeliveIn->lat); ?>&z=15&output=embed" style="width: 100%;height: 500px;"></iframe>
			      </div>
				</div>
				<div class="col-md-6">
					<div class="section-heading text-center m-b-xxs-60 m-b-md-80">
								<h2 class="wow fadeInUpSmall">Send Your Queary hare</h2>
								<h3 class="wow fadeInUpSmall" data-wow-delay=".15s">Ready to keep in touch with me for amazing things?.</h3>
								<?php if(session()->has('alert.message')): ?>
					            <div class="alert alert-<?php echo e(session('alert.status')); ?> alert-dismissable">
					                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					                <?php echo e(session('alert.message')); ?>.
					            </div>
					            <?php endif; ?>
							</div>

							<div class="row">

								<div class="col-sm-12 col-md-8 col-md-offset-2">
									 <?php echo e(Form::open(['url' => route('queary_store'), 'method' => 'post','enctype'=>'multipart/form-data','class'=>'personx-form-valid wow fadeInUpSmall'])); ?>

										<div class="row">
											<div class="col-sm-4">
												<div class="mdl-textfield mdl-js-textfield m-b-xxs-15 m-b-sm-0">
													<input class="mdl-textfield__input" name="name" placeholder="Your Name" type="text">
													<?php if($errors->has('name')): ?>
					                                <p class="help-block" style="color:red">
					                                    <?php echo e($errors->first('name')); ?>

					                                </p>
					                                <?php endif; ?>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="mdl-textfield mdl-js-textfield m-b-xxs-15 m-b-sm-0">
													<input class="mdl-textfield__input" name="email" placeholder="Your Email" type="email">
													<?php if($errors->has('email')): ?>
					                                <p class="help-block" style="color:red">
					                                    <?php echo e($errors->first('email')); ?>

					                                </p>
					                                <?php endif; ?>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="mdl-textfield mdl-js-textfield">
													<input class="mdl-textfield__input" name="subject" placeholder="Subject" type="text">
													<?php if($errors->has('subject')): ?>
					                                <p class="help-block" style="color:red">
					                                    <?php echo e($errors->first('subject')); ?>

					                                </p>
					                                <?php endif; ?>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-12">
												<div class="mdl-textfield mdl-textfield--textarea mdl-js-textfield">
													<textarea class="mdl-textfield__input" name="queary" placeholder="Your queary"></textarea>
													<?php if($errors->has('queary')): ?>
					                                <p class="help-block" style="color:red">
					                                    <?php echo e($errors->first('queary')); ?>

					                                </p>
					                                <?php endif; ?>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-12">
												<div class="text-center m-t-xxs-30 m-t-md-60">
													<button class="mdl-button mdl-button--large mdl-js-button mdl-js-ripple-effect" disabled="disabled">Submit</button>
												</div>
											</div>
										</div>
									<?php echo e(Form::close()); ?>

								</div>
							</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			
		</div>
	</div>
	<div class="container" style="margin-top: 10px">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-6">
					
				</div>
				<div class="col-md-6">
					<h3 class="heading-text-color">Contact <strong>Details</strong></h3>
	                <ul class="list-unstyled list-contact">
	                	<?php if($WeBeliveIn->mobile): ?>
                        <li><i class="zmdi zmdi-phone" style="padding: 10px; font-size: 15px;"></i><?php echo e($WeBeliveIn->mobile); ?></li>
                        <?php endif; ?>
                        <?php if($WeBeliveIn->email): ?>
                        <li><i class="zmdi zmdi-email" style="padding: 10px; font-size: 15px;"></i><?php echo e($WeBeliveIn->email); ?></li>
                        <?php endif; ?>
                        <?php if($WeBeliveIn->address): ?>
                        <li><i class="zmdi zmdi-pin" style="padding: 10px; font-size: 15px;"></i><?php echo e($WeBeliveIn->address); ?></li>
                        <?php endif; ?>
                        <?php if($WeBeliveIn->address2): ?>
                        <li><i class="zmdi zmdi-pin" style="padding: 10px; font-size: 15px;"></i><?php echo e($WeBeliveIn->address2); ?></li>
                        <?php endif; ?>
                        <?php if($WeBeliveIn->address3): ?>
                        <li><i class="zmdi zmdi-pin" style="padding: 10px; font-size: 15px;"></i><?php echo e($WeBeliveIn->address3); ?></li>
                        <?php endif; ?>
	                </ul>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontent.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>