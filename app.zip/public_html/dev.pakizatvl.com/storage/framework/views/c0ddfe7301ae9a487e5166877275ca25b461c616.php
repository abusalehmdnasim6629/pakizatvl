<nav class="mobile-menu visible-sm visible-xs visible-xxs">
		<div class="mobile-menu__header">
			<div class="mobile-menu__header__content">
				<img alt="mobile-menu-header-thumb" src="<?php echo e(asset('frontent/images/logo-3.png')); ?>">
			</div>
		</div>

		<ul class="cl-effect-5">
			<li>
		      	<a  href="<?php echo e(route('home')); ?>"><span data-hover="Home"><span>Home</span></span></a>
			</li>
			<li class="">
				<a href="http://pakizatvl.com/contents/about/17">About Us</a>
				<!--<ul class="dropdown-menu">-->
				<!--	<?php $__currentLoopData = $AllAbout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
    <!--                <?php if($Content->type =='about'): ?>-->
				<!--	<li>-->
				<!--		<a href="<?php echo e(route('home_content_view',['about',$Content->id])); ?>"><?php echo e($Content->title); ?></a>-->
				<!--	</li>-->
				<!--	<?php endif; ?>-->
				<!--	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
				<!--</ul>-->
			</li>
			<li class="dropdown-item">
					<a href="javascript:void(0)">Products</a>
					<ul class="dropdown-menu">
						<?php $__currentLoopData = $AllContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <?php if($Content->type =='products'): ?>
						<li>
							<a href="<?php echo e(route('home_content_view',['products',$Content->id])); ?>"><?php echo e($Content->title); ?></a>
						</li>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</li>
				<li class="dropdown-item">
					<a href="javascript:void(0)">Solution</a>
					<ul class="dropdown-menu">
						<?php $__currentLoopData = $AllContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <?php if($Content->type =='solutions'): ?>
						<li>
							<a href="<?php echo e(route('home_content_view',['solutions',$Content->id])); ?>"><?php echo e($Content->title); ?></a>
						</li>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</li>
				<li>
					<a href="<?php echo e(route('home_contents',['sister-concerns'])); ?>">Sister Concern's</a>
				</li>
				<li>
					<a href="<?php echo e(route('contact_us')); ?>">Contact Us</a>
				</li>
				<li>
					<a href="<?php echo e(route('home_query')); ?>">Query</a>
				</li>
		</ul>
	</nav>