<?php $__env->startSection('content'); ?>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Content Add Form
            </div>
            <div class="panel-body">
                <div class="row">
                    <?php if(session()->has('alert.message')): ?>
                    <div class="alert alert-<?php echo e(session('alert.status')); ?> alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(session('alert.message')); ?>.
                    </div>
                    <?php endif; ?>
                    <div class="col-lg-12">
                        <?php echo e(Form::open(['url' => route('setting_update',[$slug,$about->id]), 'method' => 'post','enctype'=>'multipart/form-data'])); ?>

                        <?php if($slug=='we-belive-in'): ?>
                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <label>About</label>
                                    <textarea name="about" class="form-control" rows="3" ><?php echo e($about->about); ?></textarea>
                                    
                                    <?php if($errors->has('about')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('about')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label>Service Excellence</label>
                                    <textarea name="wbi1" class="form-control" rows="3" ><?php echo e($about->wbi1); ?></textarea>
                                    
                                    <?php if($errors->has('wbi1')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('wbi1')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label>Rights to Know</label>
                                    <textarea name="wbi2" class="form-control" rows="3" ><?php echo e($about->wbi2); ?></textarea>
                                    
                                    <?php if($errors->has('wbi2')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('wbi2')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label>Hight Quality</label>
                                    <textarea name="wbi3" class="form-control" rows="3" ><?php echo e($about->wbi3); ?></textarea>
                                    
                                    <?php if($errors->has('wbi3')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('wbi3')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label>Visibility</label>
                                    <textarea name="wbi4" class="form-control" rows="3" ><?php echo e($about->wbi4); ?></textarea>
                                    
                                    <?php if($errors->has('wbi4')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('wbi4')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label>Value for money</label>
                                    <textarea name="wbi5" class="form-control" rows="3" ><?php echo e($about->wbi5); ?></textarea>
                                    
                                    <?php if($errors->has('wbi5')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('wbi5')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label>Customer Satisfaction</label>
                                    <textarea name="wbi6" class="form-control" rows="3" ><?php echo e($about->wbi6); ?></textarea>
                                    
                                    <?php if($errors->has('wbi6')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('wbi6')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php elseif($slug=='information'): ?>
                            <div class="row">
                            	<div class="col-md-6 form-group">
                                    <label>Mobile</label>
                                    <input name="mobile" class="form-control" value="<?php echo e($about->mobile); ?>">
                                    
                                    <?php if($errors->has('mobile')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('mobile')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Email</label>
                                    <input name="email" class="form-control" value="<?php echo e($about->email); ?>">
                                    
                                    <?php if($errors->has('email')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('email')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label>Address</label>
                                    <input name="address" class="form-control" value="<?php echo e($about->address); ?>">
                                    
                                    <?php if($errors->has('address')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('address')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label>Address 2</label>
                                    <input name="address2" class="form-control" value="<?php echo e($about->address2); ?>">
                                    
                                    <?php if($errors->has('address2')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('address2')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label>Address 3</label>
                                    <input name="address3" class="form-control" value="<?php echo e($about->address3); ?>">
                                    
                                    <?php if($errors->has('address3')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('address3')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                            	<div class="col-md-3 form-group">
                                    <label>Facebook</label>
                                    <input name="fb" class="form-control" value="<?php echo e($about->fb); ?>">
                                    
                                    <?php if($errors->has('fb')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('fb')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label>Twitter</label>
                                    <input name="tw" class="form-control" value="<?php echo e($about->tw); ?>">
                                    
                                    <?php if($errors->has('tw')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('tw')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label>Google +</label>
                                    <input name="gl" class="form-control" value="<?php echo e($about->gl); ?>">
                                    
                                    <?php if($errors->has('gl')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('gl')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label>Linkedin</label>
                                    <input name="lin" class="form-control" value="<?php echo e($about->lin); ?>">
                                    
                                    <?php if($errors->has('lin')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('lin')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label>Longitude</label>
                                    <input name="lng" class="form-control" value="<?php echo e($about->lng); ?>">
                                    
                                    <?php if($errors->has('lng')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('lng')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label>Latitude </label>
                                    <input name="lat" class="form-control" value="<?php echo e($about->lat); ?>">
                                    
                                    <?php if($errors->has('lat')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('lat')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php else: ?>
                        <div class="row">
                        	 <div class="col-md-12 form-group">
                                <label>Contact Page Image</label>
                                <?php if($about->contact_image!=''): ?>
                                <img src="<?php echo e(url($about->contact_image)); ?>" style="width: 100%;">
                                <?php endif; ?>
                                <input name="contact_image" type="file">
                                <?php if($errors->has('contact_image')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('contact_image')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>About Page Image</label>
                                <?php if($about->about_image!=''): ?>
                                <img src="<?php echo e(url($about->about_image)); ?>" style="width: 100%;">
                                <?php endif; ?>
                                <input name="about_image" type="file">
                                <?php if($errors->has('about_image')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('about_image')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>Product & Solution Page Image</label>
                                <?php if($about->product_image!=''): ?>
                                <img src="<?php echo e(url($about->product_image)); ?>" style="width: 100%;">
                                <?php endif; ?>
                                <input name="product_image" type="file">
                                <?php if($errors->has('product_image')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('product_image')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>Brand's Page Image</label>
                                <?php if($about->brand_image!=''): ?>
                                <img src="<?php echo e(url($about->brand_image)); ?>" style="width: 100%;">
                                <?php endif; ?>
                                <input name="brand_image" type="file">
                                <?php if($errors->has('brand_image')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('brand_image')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>Sister Concern's Page Image</label>
                                <?php if($about->sister_image!=''): ?>
                                <img src="<?php echo e(url($about->sister_image)); ?>" style="width: 100%;">
                                <?php endif; ?>
                                <input name="sister_image" type="file">
                                <?php if($errors->has('sister_image')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('sister_image')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                            <button type="submit" class="btn btn-default">Submit Button</button>
                            <a href="<?php echo e(url('settings',[$slug])); ?>" type="reset" class="btn btn-default">Reset Button</a>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>