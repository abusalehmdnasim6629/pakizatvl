
<?php $__env->startSection('content'); ?>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Content Add Form
            </div>
            <div class="panel-body">
                <div class="row">
                    <?php if(session()->has('alert.message')): ?>
                    <div class="alert alert-<?php echo e(session('alert.status')); ?> alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(session('alert.message')); ?>.
                    </div>
                    <?php endif; ?>
                    <div class="col-lg-12">
                        <?php echo e(Form::open(['url' => route('content_store',[$slug]), 'method' => 'post','enctype'=>'multipart/form-data'])); ?>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Title</label>
                                    <input name="title" class="form-control" value="<?php echo e(old('title')); ?>">
                                    
                                    <?php if($errors->has('title')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('title')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <?php if($slug=='sister-concerns'): ?>
                                <div class="col-md-6 form-group">
                                    <label>Web Site Link</label>
                                    <input name="link" class="form-control" value="<?php echo e(old('link')); ?>">
                                    <?php if($errors->has('link')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('link')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                                <!-- <?php elseif($slug=='about'): ?>
                                <div class="col-md-6 form-group">
                                    <label>Select Type</label>
                                    <select class="form-control" name="type">
                                        <option value="">Select Type</option>
                                        <?php if(old('type')==1): ?>
                                        <option value="1" selected>WHY CHOOSE US</option>
                                        <?php else: ?>
                                        <option value="1">WHY CHOOSE US</option>
                                        <?php endif; ?>
                                        <?php if(old('type')==2): ?>
                                        <option value="2" selected>Corporate Governance</option>
                                        <?php else: ?>
                                        <option value="2">Corporate Governance</option>
                                        <?php endif; ?>
                                        <?php if(old('type')==3): ?>
                                        <option value="3" selected>Management</option>
                                        <?php else: ?>
                                        <option value="3">Management</option>
                                        <?php endif; ?>
                                        <?php if(old('type')==4): ?>
                                        <option value="4" selected>Excellence</option>
                                        <?php else: ?>
                                        <option value="4" >Excellence</option>
                                        <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('type')): ?>
                                    <p class="help-block" style="color:red">
                                        <?php echo e($errors->first('type')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div> -->
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Summery</label>
                                <textarea name="summery" class="form-control" rows="3" id="editor_summery"><?php echo e(old('summery')); ?></textarea>
                                <?php if($errors->has('summery')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('summery')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Details</label>
                                <textarea name="details" class="form-control" rows="3" id="editor_details"><?php echo e(old('details')); ?></textarea>
                                <?php if($errors->has('details')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('details')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                            <?php if($slug=='products' || $slug=='solutions'): ?>    
                            <div class="col-md-4 form-group">
                                <label>Slider Image</label>
                                <input name="image" type="file">
                                <?php if($errors->has('image')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('image')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-4 form-group">
                                <label>Thumnail Image</label>
                                <input name="thumnail" type="file">
                                <?php if($errors->has('thumnail')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('thumnail')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <?php elseif($slug=='services'): ?>
                            <div class="col-md-4 form-group">
                                <label>Png Logo Or Thumnail</label>
                                <input name="thumnail" type="file">
                                <?php if($errors->has('thumnail')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('thumnail')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <?php elseif($slug=='clients' || $slug=='brands'): ?>
                            <div class="col-md-4 form-group">
                                <label>Png Logo Or Thumnail</label>
                                <input name="thumnail" type="file">
                                <?php if($errors->has('thumnail')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('thumnail')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <?php elseif($slug=='sister-concerns'): ?>
                            <div class="col-md-4 form-group">
                                <label>Thumnail Image</label>
                                <input name="thumnail" type="file">
                                <?php if($errors->has('thumnail')): ?>
                                <p class="help-block" style="color:red">
                                    <?php echo e($errors->first('thumnail')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <?php if($slug!='about'): ?>
                            <div class="col-md-4 form-group">
                                <label>Status</label>
                                <div class="checkbox">
                                    <label>
                                        <input name="status" type="checkbox">Show on Home page
                                    </label>
                                </div>
                            </div>
                            <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-default">Submit Button</button>
                            <a href="<?php echo e(url('content_add',[$slug])); ?>" type="reset" class="btn btn-default">Reset Button</a>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>