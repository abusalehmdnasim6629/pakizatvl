<nav class="mobile-menu visible-sm visible-xs visible-xxs">
		<div class="mobile-menu__header">
			<div class="mobile-menu__header__content">
				<img alt="mobile-menu-header-thumb" src="img/mobile-menu-header-thumb.jpg">
			</div>
		</div>

		<ul class="cl-effect-5">
			<li>
				<a href="index.html">Home</a>
			</li>
			<li class="dropdown-item">
				<a href="javascript:void(0)">About Us</a>
				<ul class="dropdown-menu">
					<li>
						<a href="about-us.html">WHY CHOOSE US</a>
					</li>
					<li class="dropdown-item">
						<a href="javascript:void(0)">Corporate Governance</a>
						<ul class="dropdown-menu">
							<li>
								<a href="about-us.html">Mission, Vision & Values</a>
							</li>
							<li>
								<a href="about-us.html">Service Agreement Template</a>
							</li>
							<li>
								<a href="about-us.html">Warranty Policies</a>
							</li>
						</ul>
					</li>
					<li class="dropdown-item">
						<a href="javascript:void(0)">Management</a>
						<ul class="dropdown-menu">
							<li>
								<a href="about-us.html">Chairman's Chamber</a>
							</li>
							<li>
								<a href="about-us.html">Managing Director's Chamber</a>
							</li>
							<li>
								<a href="about-us.html">Executive Council</a>
							</li>
						</ul>
					</li>
					<li class="dropdown-item">
						<a href="javascript:void(0)">Excellence</a>
						<ul class="dropdown-menu">
							<li>
								<a href="about-us.html">Business Excellence</a>
							</li>
							<li>
								<a href="about-us.html">Innovation</a>
							</li>
							<li>
								<a href="about-us.html">Future Thinking</a>
							</li>
						</ul>
					</li>
				</ul>
			</li>
			<li class="dropdown-item">
				<a href="javascript:void(0)">Products & Solution</a>
				<ul class="dropdown-menu">
					<li>
						<a href="data-center-cloud-solution.html">Data Center & Cloud Solutions</a>
					</li>
					<li>
						<a href="network-infrastructure-security.html">Network Infrastructure & Security</a>
					</li>
					<li>
						<a href="servers-strorages.html">Servers & Storages</a>
					</li>
					<li>
						<a href="security-surveillance.html">Security & Surveillance</a>
					</li>
					<li>
						<a href="software-process-automation.html">Software & Process Automation</a>
					</li>
					<li>
						<a href="endpoint-computing.html">Endpoint Computing</a>
					</li>
				</ul>
			</li>
			<li>
				<a href="sister-concerns.html">Sister Concern's</a>
			</li>
			<li>
				<a href="contact-us.html">Contact Us</a>
			</li>
			<li>
				<a href="queary.html">Queary</a>
			</li>
		</ul>
	</nav>