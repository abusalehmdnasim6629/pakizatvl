<!DOCTYPE html>
<html class="matx no-js">
<head>
	<meta charset="utf-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="Material Design Personal Template" name="description">
	<meta content="width=device-width,initial-scale=1" name="viewport">
	<title>Pakiza</title>
	<link href="<?php echo e(asset('frontent/images/222.png')); ?>" rel="shortcut icon" type="image/x-icon">
	<link href="<?php echo e(asset('frontent/images/222.png')); ?>" rel="apple-touch-icon">
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,400italic,500,700italic,700,500italic,900" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('frontent/assets/libs/material-design-iconic-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/libs/ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/libs/mdl/material.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/libs/owl-carousel/owl.carousel.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/libs/owl-carousel/owl.theme.default.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/libs/magnific-popup/magnific-popup.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/libs/sweetalert/sweet-alert.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/libs/sweetalert/ie9.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/libs/animate/animate.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/css/common.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontent/assets/css/main.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontent/sample.css')); ?>" media="all" />
    <link rel="stylesheet" type="text/css" href="https://raw.githubusercontent.com/daneden/animate.css/master/animate.css">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
	<div class="preloader" id="loader">
		<div class="preloader__inner"></div>
	</div>
	<div class="mobile-menu-trigger visible-sm visible-xs visible-xxs">
		<button class="hamburger hamburger--spin" type="button"><span class="hamburger-box"><span class="hamburger-inner"></span></span></button>
	</div>
	<?php echo $__env->make('frontent.mobile_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('header'); ?>
	<?php echo $__env->yieldContent('content'); ?>
	<footer class="footer">
		<section class="footer__bottom">
			<div class="container" style="width: 100%; position: absolute;">
				<div class="footer__bottom__text" style="position: relative; float: left; width: 50%     text-align: left;">
					<p style="color: #036;font-size:14px;font-family: Helvetica Neue; padding: 5px;" >Pakiza Technovation Limited &copy; 2018. All Rights Reserved.</p>
				</div>
				<div class="footer__bottom__text" style="position: relative; float: right; width: 50% text-align: right; right: 135px;">
					<img style="width: 40px;" src="<?php echo e(url('frontent/images/logo-2.png')); ?>">
				</div>
			</div>
		</section>
	</footer>
	<div class="footer__top__inner text-center" style="background-color: #036;
    
    right: 0px;
    bottom: 150px;
    color: #fff;
    font-size: 30px;
    width: 50px;
    z-index: 99999;
    position: fixed;">
		<ul>
			<li class="">
				<a href="<?php echo e($WeBeliveIn->fb); ?>"><i class="zmdi zmdi-facebook"></i></a>
			</li>
			<li class=" " >
				<a href="<?php echo e($WeBeliveIn->tw); ?>"><i class="zmdi zmdi-twitter"></i></a>
			</li>
			<li class=" " >
				<a href="<?php echo e($WeBeliveIn->gl); ?>"><i class="zmdi zmdi-google-plus"></i></a>
			</li>
			<li class="">
				<a href="<?php echo e($WeBeliveIn->lin); ?>"><i class="zmdi zmdi-linkedin"></i></a>
			</li>
			<li class="">
				<a href="<?php echo e(route('home_queary')); ?>"><i class="zmdi zmdi-email-open"></i></a>
			</li>
		</ul>
	</div>
	<button class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect back-to-top shade-on hide-right" id="backToTop"><i class="zmdi zmdi-chevron-down"></i>
	</button>
	<script>
	window.jQuery || document.write('<script src="<?php echo e(asset('frontent/assets/js/vendor/jquery-1.12.4.min.js')); ?>"><\/script>')
	</script>
	<script src="https://maps.google.com/maps/api/js?key=AIzaSyA9ubLXMECtXi8WQCt-UFZeSNiJbdKhOaM">
	</script>
	<script src="<?php echo e(asset('frontent/assets/js/plugins.js')); ?>">
	</script>
	<script src="<?php echo e(asset('frontent/assets/libs/jwplayer/jwplayer.js')); ?>">
	</script>
	<script src="<?php echo e(asset('frontent/assets/js/components.js')); ?>">
	</script><!-- Mirrored from personx-html.coderpixel.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Oct 2018 12:10:40 GMT -->
	<script type="text/javascript" src="<?php echo e(asset('frontent/js/jquery.flexslider-min.js')); ?>"></script>
	<?php echo $__env->yieldContent('scripts'); ?>
    <script type="text/javascript" charset="utf-8">
    var $ = jQuery.noConflict();
    $(window).load(function() {
    $('.flexslider').flexslider({
          animation: "fade"
    });
	
	$(function() {
		$('.show_menu').click(function(){
				$('.menu').fadeIn();
				$('.show_menu').fadeOut();
				$('.hide_menu').fadeIn();
		});
		$('.hide_menu').click(function(){
				$('.menu').fadeOut();
				$('.show_menu').fadeIn();
				$('.hide_menu').fadeOut();
		});
	});
  });
</script>
</body>
</html>