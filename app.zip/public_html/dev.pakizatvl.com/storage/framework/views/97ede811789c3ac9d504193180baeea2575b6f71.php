<?php $__env->startSection('title'); ?>
<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('frontent.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- <section class="banner banner--small section-main overflow-hidden">
	<div class="bg-parallax" data-top="transform: translate3d(0px, 0px, 0px); opacity: 1;" data-top-bottom="transform: translate3d(0px, 250px, 0px); opacity: 0;"></div>
	<div class="banner__v-center">
		<div class="container">
			<div class="row">
				<div class="col-xxs-12">
					<div class="banner__content banner__content--2">
						<div class="banner__content__text">
							<h2 class="wow fadeInLeftSmall">Sister Concern's</h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> -->
<section class="blog-posts section-main section-padding section" id="blog" style="margin-top: 65px;">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="row">
					<div id="blog-posts-mesonary">
						<?php $__currentLoopData = $Contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<article class="col-xxs-3 col-sm-3 col-md-2 single-blog-post">
							<a href="<?php echo e(route('home_content_view',[$slug,$Content->id])); ?>">
							<div class="mdl-card jumbo-shadow mdl-shadow--2dp" style="text-align: center;">
								<div class="post-thumb-wrap">
									<img style="height: 150px; padding: 10px;" src="<?php echo e(asset($Content->thumnail)); ?>">
								</div>
								<div class="post-content-wrap">
									<p><?php echo e($Content->title); ?></p>
								</div>
							</div>
							</a>
						</article>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontent.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>