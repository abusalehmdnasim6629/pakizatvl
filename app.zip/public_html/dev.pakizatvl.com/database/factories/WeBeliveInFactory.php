<?php

use Faker\Generator as Faker;

$factory->define(App\WeBeliveIn::class, function (Faker $faker) {
    return [
        //
    ];
});
