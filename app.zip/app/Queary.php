<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Queary extends Model
{
    //
}
