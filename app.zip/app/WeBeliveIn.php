<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WeBeliveIn extends Model
{
    //
}
